-- Add explicit SELECT policy for user_roles - only admins can view role assignments
CREATE POLICY "Admins can view user roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));