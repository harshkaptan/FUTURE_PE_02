import { Upload, Cpu, FileCheck } from "lucide-react";

const steps = [
  {
    icon: Upload,
    step: "01",
    title: "Upload Your Resume",
    description: "Simply upload your existing resume in PDF or Word format. Our system accepts all common document types.",
  },
  {
    icon: Cpu,
    step: "02",
    title: "AI Analyzes Content",
    description: "Our advanced AI engine scans your resume, evaluating content, structure, keywords, and ATS compatibility.",
  },
  {
    icon: FileCheck,
    step: "03",
    title: "Get Actionable Insights",
    description: "Receive detailed feedback with specific suggestions to improve your resume and increase interview chances.",
  },
];

const HowItWorksSection = () => {
  return (
    <section id="how-it-works" className="py-24 px-6 bg-secondary">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-display-md text-foreground mb-4">
              How It Works
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto">
              Transform your resume in three simple steps. It takes less than a minute to get started.
            </p>
          </div>

          {/* Steps */}
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((item, index) => (
              <div key={item.step} className="relative">
                {/* Connector line */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-16 left-1/2 w-full h-px bg-border" />
                )}
                
                <div className="relative bg-card rounded-2xl p-8 shadow-subtle text-center">
                  {/* Step number */}
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground text-xl font-bold mb-6">
                    {item.step}
                  </div>
                  
                  {/* Icon */}
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <item.icon className="w-7 h-7 text-primary" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-foreground mb-3">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
