import { Zap, Target, BarChart3, Lightbulb } from "lucide-react";

const benefits = [
  {
    icon: Zap,
    title: "Instant Feedback",
    description: "Get comprehensive analysis of your resume in seconds, not hours.",
  },
  {
    icon: Target,
    title: "ATS Optimization",
    description: "Ensure your resume passes Applicant Tracking Systems every time.",
  },
  {
    icon: BarChart3,
    title: "Industry Insights",
    description: "Tailored recommendations based on your target industry and role.",
  },
  {
    icon: Lightbulb,
    title: "Personalized Tips",
    description: "Actionable suggestions to improve content, formatting, and impact.",
  },
];

const BenefitsSection = () => {
  return (
    <section className="py-24 px-6 bg-secondary">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-display-md text-foreground mb-4">
              Why Choose AI Resume Analyzer
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto">
              Leverage cutting-edge AI technology to give your resume the competitive edge it deserves.
            </p>
          </div>

          {/* Benefits Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div
                key={benefit.title}
                className="group bg-card rounded-2xl p-8 shadow-subtle hover:shadow-card transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <benefit.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {benefit.title}
                </h3>
                <p className="text-muted-foreground">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
