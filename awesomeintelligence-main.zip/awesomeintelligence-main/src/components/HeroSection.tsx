import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

interface HeroSectionProps {
  onOpenChat: () => void;
}

const HeroSection = ({ onOpenChat }: HeroSectionProps) => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center pt-20 pb-16 px-6">
      <div className="container mx-auto">
        <div className="max-w-5xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-secondary text-secondary-foreground rounded-full px-4 py-2 mb-8 animate-fade-in">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">AI-Powered Resume Analysis</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-display-lg md:text-display-xl text-foreground mb-6 animate-fade-in-up text-balance">
            Transform Your Resume with{" "}
            <span className="text-primary">awesome intelligence</span>
          </h1>

          {/* Subheadline */}
          <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto mb-10 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            Get instant, actionable feedback on your resume. Our AI analyzes your content, 
            optimizes for ATS systems, and helps you stand out to recruiters.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <Button
              onClick={onOpenChat}
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 py-6 text-lg font-medium shadow-elevated hover:shadow-card transition-all"
            >
              Ask AI About This Product
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button
              onClick={() => scrollToSection("pricing")}
              variant="outline"
              size="lg"
              className="rounded-full px-8 py-6 text-lg font-medium border-border hover:bg-secondary"
            >
              View Pricing
            </Button>
          </div>

          {/* Product Mockup */}
          <div className="relative animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
            <div className="relative mx-auto max-w-4xl">
              {/* MacBook Frame */}
              <div className="relative bg-apple-graphite rounded-t-2xl p-3 pb-0">
                {/* Camera notch */}
                <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-foreground/20" />
                
                {/* Screen */}
                <div className="bg-gradient-to-br from-secondary to-background rounded-t-lg overflow-hidden shadow-elevated">
                  <div className="aspect-[16/10] relative">
                    {/* Browser chrome */}
                    <div className="bg-secondary border-b border-border px-4 py-2 flex items-center gap-2">
                      <div className="flex gap-1.5">
                        <div className="w-3 h-3 rounded-full bg-destructive/60" />
                        <div className="w-3 h-3 rounded-full bg-primary/40" />
                        <div className="w-3 h-3 rounded-full bg-primary/60" />
                      </div>
                      <div className="flex-1 mx-4">
                        <div className="bg-background rounded-md h-6 max-w-md mx-auto" />
                      </div>
                    </div>
                    
                    {/* App content preview */}
                    <div className="p-8 bg-background">
                      <div className="max-w-2xl mx-auto space-y-6">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                            <Sparkles className="w-6 h-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <div className="h-4 bg-foreground/10 rounded w-48 mb-2" />
                            <div className="h-3 bg-foreground/5 rounded w-32" />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4">
                          <div className="p-4 bg-secondary rounded-xl">
                            <div className="w-8 h-8 rounded-lg bg-primary/20 mb-3" />
                            <div className="h-3 bg-foreground/10 rounded w-20 mb-2" />
                            <div className="h-2 bg-foreground/5 rounded w-full" />
                          </div>
                          <div className="p-4 bg-secondary rounded-xl">
                            <div className="w-8 h-8 rounded-lg bg-primary/20 mb-3" />
                            <div className="h-3 bg-foreground/10 rounded w-20 mb-2" />
                            <div className="h-2 bg-foreground/5 rounded w-full" />
                          </div>
                          <div className="p-4 bg-secondary rounded-xl">
                            <div className="w-8 h-8 rounded-lg bg-primary/20 mb-3" />
                            <div className="h-3 bg-foreground/10 rounded w-20 mb-2" />
                            <div className="h-2 bg-foreground/5 rounded w-full" />
                          </div>
                        </div>
                        
                        <div className="p-4 bg-primary/5 rounded-xl border border-primary/20">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-6 h-6 rounded-full bg-primary/20" />
                            <div className="h-3 bg-primary/30 rounded w-24" />
                          </div>
                          <div className="space-y-2">
                            <div className="h-2 bg-primary/10 rounded w-full" />
                            <div className="h-2 bg-primary/10 rounded w-4/5" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* MacBook base */}
              <div className="h-4 bg-apple-graphite rounded-b-xl" />
              <div className="h-2 bg-apple-gray-dark rounded-b-lg mx-16" />
            </div>
            
            {/* Floating elements for visual interest */}
            <div className="absolute -left-8 top-1/4 w-20 h-20 bg-primary/10 rounded-2xl blur-2xl animate-float" />
            <div className="absolute -right-8 top-1/3 w-32 h-32 bg-primary/5 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
