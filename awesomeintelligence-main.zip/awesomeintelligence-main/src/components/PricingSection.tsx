import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "Perfect for trying out AI Resume Analyzer",
    features: [
      "3 resume scans per month",
      "Basic ATS compatibility check",
      "General feedback",
      "Standard processing",
    ],
    cta: "Get Started",
    highlighted: false,
  },
  {
    name: "Pro",
    price: "$9",
    period: "per month",
    description: "For serious job seekers who want to stand out",
    features: [
      "Unlimited resume scans",
      "Advanced ATS optimization",
      "Keyword analysis & suggestions",
      "Industry-specific insights",
      "Priority processing",
      "Export detailed reports",
    ],
    cta: "Start Pro Trial",
    highlighted: true,
  },
  {
    name: "Team",
    price: "$29",
    period: "per month",
    description: "For recruiters and career coaches",
    features: [
      "Everything in Pro",
      "Up to 10 team members",
      "Bulk resume analysis",
      "Candidate comparison",
      "Custom scoring criteria",
      "Priority support",
      "API access",
    ],
    cta: "Contact Sales",
    highlighted: false,
  },
];

const PricingSection = () => {
  return (
    <section id="pricing" className="py-24 px-6 bg-secondary">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-display-md text-foreground mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto">
              Choose the plan that fits your needs. No hidden fees, cancel anytime.
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative rounded-2xl p-8 ${
                  plan.highlighted
                    ? "bg-foreground text-background shadow-elevated scale-105"
                    : "bg-card text-foreground border border-border shadow-subtle"
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-sm font-medium px-4 py-1 rounded-full">
                    Most Popular
                  </div>
                )}
                
                <div className="mb-8">
                  <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-2">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className={plan.highlighted ? "text-background/60" : "text-muted-foreground"}>
                      /{plan.period}
                    </span>
                  </div>
                  <p className={plan.highlighted ? "text-background/80" : "text-muted-foreground"}>
                    {plan.description}
                  </p>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                        plan.highlighted ? "text-primary" : "text-primary"
                      }`} />
                      <span className={plan.highlighted ? "text-background/90" : "text-foreground"}>
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full rounded-full py-6 text-base font-medium ${
                    plan.highlighted
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border"
                  }`}
                >
                  {plan.cta}
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
