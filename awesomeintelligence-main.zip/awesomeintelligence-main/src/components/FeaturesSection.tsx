import { FileText, Shield, TrendingUp, Clock, Users, Award } from "lucide-react";

const features = [
  {
    icon: FileText,
    title: "Smart Content Analysis",
    description: "AI-powered deep analysis of your resume content, identifying strengths and areas for improvement.",
  },
  {
    icon: Shield,
    title: "ATS Compatibility Check",
    description: "Ensure your resume is optimized for Applicant Tracking Systems used by top companies.",
  },
  {
    icon: TrendingUp,
    title: "Keyword Optimization",
    description: "Get suggestions for industry-specific keywords that increase your visibility to recruiters.",
  },
  {
    icon: Clock,
    title: "Real-time Feedback",
    description: "Receive instant analysis and suggestions as you update your resume.",
  },
  {
    icon: Users,
    title: "Role-Specific Insights",
    description: "Tailored recommendations based on your target job role and industry.",
  },
  {
    icon: Award,
    title: "Professional Formatting",
    description: "Ensure your resume follows industry-standard formatting best practices.",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-24 px-6">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-display-md text-foreground mb-4">
              Powerful Features
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to create a resume that gets noticed and lands interviews.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="group p-8 rounded-2xl border border-border hover:border-primary/30 hover:bg-secondary/50 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
