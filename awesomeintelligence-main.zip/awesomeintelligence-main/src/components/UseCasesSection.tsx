import { GraduationCap, Briefcase, UserCheck, Building2 } from "lucide-react";

const useCases = [
  {
    icon: GraduationCap,
    title: "Students",
    description: "Starting your career? Get guidance on creating your first professional resume that stands out to entry-level recruiters.",
    features: ["Academic to professional translation", "Highlight relevant coursework", "Internship optimization"],
  },
  {
    icon: Briefcase,
    title: "Job Seekers",
    description: "Looking for your next opportunity? Optimize your resume to match job descriptions and pass ATS filters.",
    features: ["Keyword optimization", "ATS score improvement", "Role-specific suggestions"],
  },
  {
    icon: UserCheck,
    title: "Professionals",
    description: "Advancing your career? Ensure your resume reflects your experience and positions you for leadership roles.",
    features: ["Executive summary crafting", "Achievement quantification", "Industry benchmarking"],
  },
  {
    icon: Building2,
    title: "Recruiters",
    description: "Helping candidates succeed? Use our tool to provide data-driven feedback to your talent pool.",
    features: ["Bulk resume analysis", "Candidate comparison", "Standardized scoring"],
  },
];

const UseCasesSection = () => {
  return (
    <section className="py-24 px-6">
      <div className="container mx-auto">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-display-md text-foreground mb-4">
              Built for Everyone
            </h2>
            <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto">
              Whether you're starting out or climbing the ladder, our AI adapts to your needs.
            </p>
          </div>

          {/* Use Cases Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {useCases.map((useCase) => (
              <div
                key={useCase.title}
                className="group bg-card rounded-2xl p-8 border border-border hover:border-primary/30 hover:shadow-card transition-all duration-300"
              >
                <div className="flex items-start gap-6">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                    <useCase.icon className="w-7 h-7 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      {useCase.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      {useCase.description}
                    </p>
                    <ul className="space-y-2">
                      {useCase.features.map((feature) => (
                        <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default UseCasesSection;
